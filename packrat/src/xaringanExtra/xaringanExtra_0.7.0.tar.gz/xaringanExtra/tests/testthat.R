library(testthat)
library(xaringanExtra)

test_check("xaringanExtra")
